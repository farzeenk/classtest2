let search = document.querySelector('.search-box');

document.querySelector('#search-icon').onclick = () => {
    search.classlist .toggle('active');
}

let menu = document.querySelector('.navbar');

document.querySelector('#menu-icon').onclick = () => {
    menu.classlist .toggle('active');
}

let header = document.querySelector('header');

window.addEventListner('scroll' , () =>{
    header.classlist.toggle('shadow', window.scrollY> 0);
});


